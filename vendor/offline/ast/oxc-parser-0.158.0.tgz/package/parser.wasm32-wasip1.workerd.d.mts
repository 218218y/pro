// napi-rs-wasi-root-facade:{"version":1,"flavorPackage":"@oxc-parser/binding-wasm32-wasip1","wasmSha256":"14cd17ef66d0e16aeb057d86d48e046877e447b098031b2678c2e013124f35b1"}
export * from "@oxc-parser/binding-wasm32-wasip1/workerd"

// napi-rs-wasi-root-facade:{"version":1,"flavorPackage":"@oxc-parser/binding-wasm32-wasip1","wasmSha256":"2b4410a1f789bc2d872390dbdb1b387d7175c3f187f3795fbf344c97fc8c9e74"}
export * from "@oxc-parser/binding-wasm32-wasip1/workerd"

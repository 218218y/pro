// napi-rs-wasi-root-facade:{"version":1,"flavorPackage":"@oxc-parser/binding-wasm32-wasip1","wasmSha256":"8d2f34229729c6d0a601227f13fac0fc2ca7207ba25233e6d0f848fbd8022ea1"}
export * from "@oxc-parser/binding-wasm32-wasip1/workerd"

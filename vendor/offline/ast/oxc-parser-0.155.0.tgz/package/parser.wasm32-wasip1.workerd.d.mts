// napi-rs-wasi-root-facade:{"version":1,"flavorPackage":"@oxc-parser/binding-wasm32-wasip1","wasmSha256":"f6044d057d32714a1dfded7455337630d7c4ee0a959491c0216ad2f0c24d74b4"}
export * from "@oxc-parser/binding-wasm32-wasip1/workerd"

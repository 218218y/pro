// napi-rs-wasi-root-facade:{"version":1,"flavorPackage":"@oxc-parser/binding-wasm32-wasip1","wasmSha256":"d4ec162efe5e8e5b3e9a3ef3fd5d2bd6228061bc17ef5eb2b049b01a53ac2edc"}
export * from "@oxc-parser/binding-wasm32-wasip1/workerd"

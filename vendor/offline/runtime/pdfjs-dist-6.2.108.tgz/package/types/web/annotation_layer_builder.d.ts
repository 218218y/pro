export type PDFPageProxy = import("../src/display/api").PDFPageProxy;
export type PageViewport = import("../src/display/page_viewport").PageViewport;
export type AnnotationStorage = import("../src/display/annotation_storage").AnnotationStorage;
export type StructTreeLayerBuilder = import("./struct_tree_layer_builder.js").StructTreeLayerBuilder;
export type TextAccessibilityManager = import("./text_accessibility.js").TextAccessibilityManager;
export type AnnotationEditorUIManager = import("../src/display/editor/tools.js").AnnotationEditorUIManager;
export type CommentManager = import("./comment_manager.js").CommentManager;
export type PDFLinkService = import("./pdf_link_service.js").PDFLinkService;
export type BaseDownloadManager = import("./base_download_manager.js").BaseDownloadManager;
export type AnnotationLayerBuilderOptions = {
    pdfPage: PDFPageProxy;
    annotationStorage?: import("../src/display/annotation_storage").AnnotationStorage | undefined;
    /**
     * - Path for image resources, mainly
     * for annotation icons. Include trailing slash.
     */
    imageResourcesPath?: string | undefined;
    renderForms: boolean;
    linkService: PDFLinkService;
    downloadManager?: import("./base_download_manager.js").BaseDownloadManager | undefined;
    enableComment?: boolean | undefined;
    enableScripting?: boolean | undefined;
    hasJSActionsPromise?: Promise<boolean> | undefined;
    fieldObjectsPromise?: Promise<{
        [x: string]: Object[];
    } | null> | undefined;
    annotationCanvasMap?: Map<string, HTMLCanvasElement> | undefined;
    accessibilityManager?: import("./text_accessibility.js").TextAccessibilityManager | undefined;
    annotationEditorUIManager?: import("../src/pdf").AnnotationEditorUIManager | undefined;
    onAppend?: Function | undefined;
    commentManager?: import("./comment_manager.js").CommentManager | undefined;
};
export type AnnotationLayerBuilderRenderOptions = {
    viewport: PageViewport;
    /**
     * - The default value is "display".
     */
    intent?: string | undefined;
    structTreeLayer?: import("./struct_tree_layer_builder.js").StructTreeLayerBuilder | undefined;
    optionalContentConfigPromise?: Promise<any> | undefined;
};
/**
 * @typedef {Object} AnnotationLayerBuilderOptions
 * @property {PDFPageProxy} pdfPage
 * @property {AnnotationStorage} [annotationStorage]
 * @property {string} [imageResourcesPath] - Path for image resources, mainly
 *   for annotation icons. Include trailing slash.
 * @property {boolean} renderForms
 * @property {PDFLinkService} linkService
 * @property {BaseDownloadManager} [downloadManager]
 * @property {boolean} [enableComment]
 * @property {boolean} [enableScripting]
 * @property {Promise<boolean>} [hasJSActionsPromise]
 * @property {Promise<Object<string, Array<Object>> | null>}
 *   [fieldObjectsPromise]
 * @property {Map<string, HTMLCanvasElement>} [annotationCanvasMap]
 * @property {TextAccessibilityManager} [accessibilityManager]
 * @property {AnnotationEditorUIManager} [annotationEditorUIManager]
 * @property {function} [onAppend]
 * @property {CommentManager} [commentManager]
 */
/**
 * @typedef {Object} AnnotationLayerBuilderRenderOptions
 * @property {PageViewport} viewport
 * @property {string} [intent] - The default value is "display".
 * @property {StructTreeLayerBuilder} [structTreeLayer]
 * @property {Promise} [optionalContentConfigPromise]
 */
export class AnnotationLayerBuilder {
    /**
     * @param {AnnotationLayerBuilderOptions} options
     */
    constructor({ pdfPage, linkService, downloadManager, annotationStorage, imageResourcesPath, renderForms, enableComment, commentManager, enableScripting, hasJSActionsPromise, fieldObjectsPromise, annotationCanvasMap, accessibilityManager, annotationEditorUIManager, onAppend, }: AnnotationLayerBuilderOptions);
    pdfPage: import("../src/display/api").PDFPageProxy;
    linkService: import("./pdf_link_service.js").PDFLinkService;
    downloadManager: import("./base_download_manager.js").BaseDownloadManager | undefined;
    imageResourcesPath: string;
    renderForms: boolean;
    annotationStorage: import("../src/display/annotation_storage").AnnotationStorage;
    enableComment: boolean;
    enableScripting: boolean;
    _hasJSActionsPromise: Promise<boolean>;
    _fieldObjectsPromise: Promise<{
        [x: string]: Object[];
    } | null>;
    _annotationCanvasMap: Map<string, HTMLCanvasElement>;
    _accessibilityManager: import("./text_accessibility.js").TextAccessibilityManager;
    _annotationEditorUIManager: import("../src/pdf").AnnotationEditorUIManager;
    annotationLayer: AnnotationLayer | null;
    div: HTMLDivElement | null;
    _cancelled: boolean;
    _eventBus: import("./event_utils.js").EventBus;
    /**
     * @param {AnnotationLayerBuilderRenderOptions} options
     * @returns {Promise<void>} A promise that is resolved when rendering of the
     *   annotations is complete.
     */
    render({ viewport, intent, structTreeLayer, optionalContentConfigPromise, }: AnnotationLayerBuilderRenderOptions): Promise<void>;
    cancel(): void;
    refreshCanvases(): void;
    hide(): void;
    hasEditableAnnotations(): boolean;
    /**
     * @param {Array<Object>} inferredLinks
     * @returns {Promise<void>} A promise that is resolved when the inferred links
     *   are added to the annotation layer.
     */
    injectLinkAnnotations(inferredLinks: Array<Object>): Promise<void>;
    #private;
}
import { AnnotationLayer } from "../src/pdf";

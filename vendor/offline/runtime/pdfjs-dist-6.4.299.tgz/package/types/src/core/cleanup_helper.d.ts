export function clearGlobalCaches(): void;

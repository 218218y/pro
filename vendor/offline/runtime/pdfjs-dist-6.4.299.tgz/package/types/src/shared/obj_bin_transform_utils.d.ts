export class CSS_FONT_INFO {
    static strings: string[];
}
export class FONT_INFO {
    static bools: string[];
    static strings: string[];
    static OFFSET_BBOX: number;
    static OFFSET_FONT_MATRIX: number;
    static OFFSET_STRINGS: number;
}
export class InfoUtils {
    static get decoder(): any;
    static get encoder(): any;
}
export class PATTERN_INFO {
    static KIND: number;
    static HAS_BBOX: number;
    static HAS_BACKGROUND: number;
    static SHADING_TYPE: number;
    static N_COORD: number;
    static N_COLOR: number;
    static N_STOP: number;
    static N_FIGURES: number;
}
export class SYSTEM_FONT_INFO {
    static strings: string[];
}
